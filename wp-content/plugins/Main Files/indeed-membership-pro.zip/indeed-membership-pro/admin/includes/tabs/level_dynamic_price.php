<form action="" method="post">
	<div class="ihc-stuffbox">
		<h3 class="ihc-h3"><?php _e('Level Dynamic Price', 'ihc');?></h3>
		<div class="inside">			
			<div class="iump-form-line">
				<h2><?php _e('Activate/Hold Level Dynamic Price', 'ihc');?></h2>
				<label class="iump_label_shiwtch" style="margin:10px 0 10px -10px;">
					<?php $checked = ($data['metas']['ihc_level_dynamic_price_on']) ? 'checked' : '';?>
					<input type="checkbox" class="iump-switch" onClick="iump_check_and_h(this, '#ihc_level_dynamic_price_on');" <?php echo $checked;?> />
					<div class="switch" style="display:inline-block;"></div>
				</label>
				<input type="hidden" name="ihc_level_dynamic_price_on" value="<?php echo $data['metas']['ihc_level_dynamic_price_on'];?>" id="ihc_level_dynamic_price_on" /> 												
			</div>	
			
			<div class="ihc-submit-form" style="margin-top: 20px;"> 
				<input type="submit" value="<?php _e('Save Changes', 'ihc');?>" name="ihc_save" class="button button-primary button-large" />
			</div>		
					
		</div>	
	</div>
</form>